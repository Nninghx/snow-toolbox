import tkinter as tk
from tkinter import messagebox
import math

class CubeRootCalculator:
    def __init__(self, root):
        self.root = root
        self.root.title("立方根计算器")
        self.root.geometry("400x300")
        self.root.resizable(False, False)
        
        # 加载并设置字体
        self.font = self.load_font_settings()
        
        # 创建界面组件
        self.create_widgets()

    def load_font_settings(self):
        """从ziti.json加载字体设置，默认返回Arial"""
        import json
        import os
        
        try:
            ziti_path = os.path.join("Core", "ziti.json")
            if os.path.exists(ziti_path):
                with open(ziti_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                return (data.get('family', 'Arial'), 12)
        except (FileNotFoundError, json.JSONDecodeError):
            pass
        return ("Arial", 12)  # 默认字体
    
    def create_widgets(self):
        # 输入框标签
        tk.Label(self.root, text="输入一个数字:", font=self.font).pack(pady=(10, 5))
        
        # 输入框
        self.input_entry = tk.Entry(self.root, font=self.font, width=30)
        self.input_entry.pack(pady=5)
        
        # 按钮框架
        button_frame = tk.Frame(self.root)
        button_frame.pack(pady=10)
        
        # 计算按钮
        self.calculate_btn = tk.Button(
            button_frame, text="计算", font=self.font, 
            command=self.calculate, bg="#4CAF50", fg="white"
        )
        self.calculate_btn.pack(side=tk.LEFT, padx=5)
        
        # 清除按钮
        self.clear_btn = tk.Button(
            button_frame, text="清除", font=self.font,
            command=self.clear, bg="#f44336", fg="white"
        )
        self.clear_btn.pack(side=tk.LEFT, padx=5)
        
        # 结果显示区域
        self.result_frame = tk.Frame(self.root, bd=2, relief=tk.GROOVE)
        self.result_frame.pack(pady=10, padx=10, fill=tk.BOTH, expand=True)
        
        # 立方根显示
        self.result_label = tk.Label(self.result_frame, text="立方根: ", font=self.font, anchor="w")
        self.result_label.pack(fill=tk.X, padx=5, pady=(5, 0))
        
        # 详细结果显示
        self.details_label = tk.Label(self.result_frame, text="计算过程: ", font=self.font, anchor="w")
        self.details_label.pack(fill=tk.X, padx=5, pady=(0, 5))
        
        # 滚动条和文本框用于显示详细信息
        scrollbar = tk.Scrollbar(self.result_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.details_text = tk.Text(
            self.result_frame, font=self.font, 
            yscrollcommand=scrollbar.set, height=6
        )
        self.details_text.pack(fill=tk.BOTH, expand=True, padx=5)
        scrollbar.config(command=self.details_text.yview)

    def calculate(self):
        # 获取输入
        input_str = self.input_entry.get().strip()
        
        # 验证输入
        if not input_str:
            messagebox.showerror("错误", "请输入数字!")
            return
        
        try:
            num = float(input_str)
            
            # 计算立方根
            cube_root = num ** (1/3)
            self.result_label.config(text=f"立方根: {cube_root:.6f}")
            
            # 显示详细信息
            self.details_text.delete(1.0, tk.END)
            self.details_text.insert(tk.END, f"计算过程:\n")
            self.details_text.insert(tk.END, f"³√{num} = {cube_root:.6f}\n\n")
            self.details_text.insert(tk.END, f"说明:\n")
            self.details_text.insert(tk.END, f"- 结果保留6位小数\n")
            self.details_text.insert(tk.END, f"- 支持正数和负数的立方根计算")
            
        except ValueError:
            messagebox.showerror("错误", "请输入有效的数字!")
    
    def clear(self):
        self.input_entry.delete(0, tk.END)
        self.result_label.config(text="立方根: ")
        self.details_label.config(text="计算过程: ")
        self.details_text.delete(1.0, tk.END)

if __name__ == "__main__":
    root = tk.Tk()
    app = CubeRootCalculator(root)
    root.mainloop()